<?php
include 'config.php';
 ?>
 <!DOCTYPE html>
 <html lang="en">
 	<head>
 		<meta charset="utf-8">
 			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 				<link href="https://fonts.googleapis.com/css?family=Muli:400,600,700" rel="stylesheet">
 					<title>CryptoMarketCheck | Stake Calculator</title>
 					<link rel="shortcut icon" type="image/x-icon" href="http://cryptomarketcheck.com/public/assets/images/favicon.png" />
 					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/assets/css/plugins.css?v=1.7" />
 					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/assets/js/amstock/style.css" />
 					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/assets/js/amstock/plugins/export/export.css" />
 					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/styles/default/css/style.css?v=1523383802" />
 					<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
 					<script src="https://code.highcharts.com/highcharts.js"></script>
 					<script src="https://code.highcharts.com/modules/exporting.js"></script>
 					<script src="https://code.highcharts.com/modules/export-data.js"></script>

           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
 					<link rel="stylesheet" href="chartlist.css" />
 					<meta name="keywords" content="" />
 					<meta name="description" content="" />

 				</head>

 				<body class="" style="">
           <nav class="navbar navbar-expand-lg navbar-dark bg-primary ">
               <a class="navbar-brand" href="#">Stake Calculator</a>
                 <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                     <span class="navbar-toggler-icon"></span>
                   </button>
                   <div class="collapse navbar-collapse" id="navbarNavDropdown">
                     <ul class="navbar-nav">
                       <li class="nav-item active">
                         <a class="nav-link" href="admin.php">Home (Admin) <span class="sr-only">(current)</span></a>
                       </li>
                     </ul>
                   </div>
           </nav>

					<div class="col-md-12">
						<div class="pane bg-white">

							<h5 style="text-align:center;margin-bottom: 26px;">Edit a coin</h5>

							<form id="alert-form" action="edit.php" method="post">
								<h5>Select a coin to edit</h5>

								<select name="coin"  class="select2 form-control">
									<?php
										// Create connection
										$conn = new mysqli($servername, $username, $password, $dbname);
										// Check connection
										if ($conn->connect_error) {
											die("Connection failed: " . $conn->connect_error);
										}

										$sql = "SELECT CoinTag, CoinName FROM coinlist";
										$result = $conn->query($sql);

										if ($result->num_rows > 0) {
											// output data of each row
											while($row = $result->fetch_assoc()) {
												$ctag   = $row['CoinTag'];
												$cname  = $row['CoinName'];
												echo "<option value='$ctag'>[$ctag] $cname</option>";
										}
										} else {
											echo "<div style='color: red;'>No coins on the Database!</div>";
										}
										$conn->close();
									 ?>
								</select>
									<br>
										<button style="display: block;margin: 0 auto; width: 104px;" class="btn btn-sm btn-primary">Go to Edit</button>
										<br>
											<a href="#" style="color: red;">Delete this coin</a>
                      <br> <a href="cleanup.php" style="color: red;">Cleanup all JSON temp files</a>
							</form>

									</div>
								</div>
								<hr>

									<div class="col-md-12">
										<div class="pane bg-white">
										<form id="alert-form" action="proccess.php" method="post">

											<h5 style="margin-bottom: 26px;">Insert a new a coin</h5>
											<form id="alert-form" action="" method="post">
												<h6 style="margin-bottom: 26px;">Coin name</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-6" style="margin-bottom: 10px;">
														<input style="height: calc(2.25rem + 2px);" type="text" name="coinname1" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">Coin TAG</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-6" style="margin-bottom: 10px;">
														<input style="height: calc(2.25rem + 2px);" type="text" name="cointag1" class="form-control" required/>
													</div>
												</div>

                        <h6 style="margin-bottom: 26px;">Start block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-6" style="margin-bottom: 10px;">
														<input placeholder="Start block" style="height: calc(2.25rem + 2px);" type="text" name="startblock1" class="form-control" required/><br>
														<input placeholder="Start block date" style="height: calc(2.25rem + 2px);" type="text" name="startblockdate1" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">1st Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock1" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock1" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime1" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi1" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">2nd Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock2" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock2" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime2" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi2" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">3rd Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock3" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock3" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime3" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi3" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">4th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock4" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock4" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime4" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi4" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">5th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock5" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock5" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime5" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi5" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">6th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock6" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock6" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime6" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi6" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">7th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock7" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock7" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime7" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi7" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">8th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock8" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock8" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime8" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi8" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">9th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock9" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock9" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime9" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi9" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">10th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock10" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock10" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime10" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi10" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">11th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock11" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock11" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime11" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi11" class="form-control" required/>
													</div>
												</div>

												<h6 style="margin-bottom: 26px;">12th Block</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Begin block " style="height: calc(2.25rem + 2px);" type="text" name="bblock12" class="form-control" required/>
														<input placeholder="End block " style="height: calc(2.25rem + 2px);" type="text" name="eblock12" class="form-control" required/>
														<input placeholder="Block time" style="height: calc(2.25rem + 2px);" type="text" name="btime12" class="form-control" required/>
														<input placeholder="ROI % " style="height: calc(2.25rem + 2px);" type="text" name="roi12" class="form-control" required/>
													</div>
												</div>

                        <h6 style="margin-bottom: 26px;">Proof of Stake Tiers</h6>
												<div class="row" style="margin-top:20px;margin-bottom: 32px">
													<div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Block" style="height: calc(2.25rem + 2px);" type="text" name="stblock1" class="form-control" required/>
														<input placeholder="Anual %" style="height: calc(2.25rem + 2px);" type="text" name="stanual1" class="form-control" required/>
														<input placeholder="Daily %" style="height: calc(2.25rem + 2px);" type="text" name="stdaily1" class="form-control" required/>
														<input placeholder="Start" style="height: calc(2.25rem + 2px);" type="text" name="ststart1" class="form-control" required/>
													</div>
                          <div class="col-md-3" style="margin-bottom: 10px;">
														<input placeholder="Block" style="height: calc(2.25rem + 2px);" type="text" name="stblock2" class="form-control" required/>
														<input placeholder="Anual %" style="height: calc(2.25rem + 2px);" type="text" name="stanual2" class="form-control" required/>
														<input placeholder="Daily %" style="height: calc(2.25rem + 2px);" type="text" name="stdaily2" class="form-control" required/>
														<input placeholder="Start" style="height: calc(2.25rem + 2px);" type="text" name="ststart2" class="form-control" required/>
													</div>
												</div>

												<button style="display: block;margin: 0 auto; width: 104px;" class="btn btn-sm btn-primary">Save Coin</button>

											</form>

										</div>
									</div>
</body>
