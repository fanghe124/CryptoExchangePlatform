<?php
include 'config.php';

?>
<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
				<link href="https://fonts.googleapis.com/css?family=Muli:400,600,700" rel="stylesheet">
					<title>CryptoMarketCheck | Stake Calculator</title>
					<link rel="shortcut icon" type="image/x-icon" href="http://cryptomarketcheck.com/public/assets/images/favicon.png" />
					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/assets/css/plugins.css?v=1.7" />
					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/assets/js/amstock/style.css" />
					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/assets/js/amstock/plugins/export/export.css" />
					<link rel="stylesheet" href="http://cryptomarketcheck.com/public/styles/default/css/style.css?v=1523383802" />
					<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
					<script src="https://code.highcharts.com/highcharts.js"></script>
					<script src="https://code.highcharts.com/modules/exporting.js"></script>
					<script src="https://code.highcharts.com/modules/export-data.js"></script>

          <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
					<link rel="stylesheet" href="chartlist.css" />
					<meta name="keywords" content="" />
					<meta name="description" content="" />

				</head>

				<body class="" style="">
          <nav class="navbar navbar-expand-lg navbar-dark bg-primary ">
              <a class="navbar-brand" href="#">Stake Calculator</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                  </button>
                  <div class="collapse navbar-collapse" id="navbarNavDropdown">
                    <ul class="navbar-nav">
                      <li class="nav-item active">
                        <a class="nav-link" href="#">Home <span class="sr-only">(current)</span></a>
                      </li>
                    </ul>
                  </div>
          </nav><br>
					<div class="container">
					<form align="center" id="alert-form" action="decide.php" method="post">

						<h5>Select a coin to calculate</h5>
						<select name="coin"  class="select2 form-control">
							<?php
								// Create connection
								$conn = new mysqli($servername, $username, $password, $dbname);
								// Check connection
								if ($conn->connect_error) {
    							die("Connection failed: " . $conn->connect_error);
								}

								$sql = "SELECT CoinTag, CoinName FROM coinlist";
								$result = $conn->query($sql);

								if ($result->num_rows > 0) {
    							// output data of each row
    							while($row = $result->fetch_assoc()) {
										$ctag   = $row['CoinTag'];
										$cname  = $row['CoinName'];
										echo "<option value='$ctag'>[$ctag] $cname</option>";
    						}
								} else {
    						 echo "<option style='color: red;' value=''>No coins :(</option>";
								}
								$conn->close();
							 ?>
						</select>

						<br>
						<h5>Show results:</h5>
						<select name="stktype"  class="select2 form-control">
							<option value='monthly'>Monthly</option>
							<option value='weekly'>Weekly</option>
							<option value='daily'>Daily</option>
						</select>

						<h6 style="margin-bottom: 26px;">Insert a coin ammount</h6>
						<div class="row" style="margin-top:20px;margin-bottom: 32px">
							<div class="col-md-6" style="margin-bottom: 10px;">
								<input style="height: calc(2.25rem + 2px);" type="text" name="quantity" class="form-control" required/>
							</div>
						</div>

						<button style="display: block;margin: 0 auto; width: 104px;" class="btn btn-sm btn-primary">Calculate</button>
				 </form>
				 </div>

</body>
